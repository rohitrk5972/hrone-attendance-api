"""Attendance API package."""
